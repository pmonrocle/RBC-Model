# RBC Model — Planificador Social

Aplicación interactiva para el modelo RBC con preferencias CRRA separables en consumo y ocio.

## Problema del Planificador Social

$$\max_{\{c_t, k_{t+1}, l_t\}} \mathbb{E}_0 \sum_{t=0}^{\infty} \beta^t \left[ \frac{c_t^{1-\sigma}-1}{1-\sigma} + \gamma \frac{(1-l_t)^{1-\psi}}{1-\psi} \right]$$

sujeto a:

$$k_{t+1} = \theta_t k_t^{\alpha} l_t^{1-\alpha} - c_t + (1-\delta)k_t$$

$$\log\theta_t = (1-\rho)\bar{\theta} + \rho\log\theta_{t-1} + \varepsilon_t, \quad \varepsilon_t \overset{iid}{\sim} \mathcal{N}(0,\sigma_\varepsilon^2)$$

## Método de Solución

1. **Estado estacionario**: FOC del planificador + condición de Euler
2. **Log-linealización** alrededor del SS determinista (θ̄ = 1)
3. **Blanchard-Kahn** vía descomposición QZ (scipy `ordqz`)
4. **Simulación** Monte Carlo con T periodos

## Funcionalidades

- 📊 Correlaciones cruzadas con ln(y/y_ss) para lags ±k
- ⚡ Funciones de Impulso-Respuesta ante shock de TFP
- 📈 Simulación de series temporales
- 📋 Tabla de momentos: volatilidades, autocorrelaciones, corr. cruzadas
- 🔧 Sliders interactivos para todos los parámetros (α, β, δ, σ, γ, ψ, ρ, σ_ε)

## Instalación local

```bash
git clone https://github.com/tu-usuario/rbc-model
cd rbc-model
pip install -r requirements.txt
streamlit run app.py
```

## Deploy en Streamlit Cloud

1. Sube este repositorio a GitHub
2. Ve a [share.streamlit.io](https://share.streamlit.io)
3. Conecta tu repo → selecciona `app.py` → Deploy

No requiere ninguna configuración adicional.

## Parámetros por defecto (Benchmark)

| Parámetro | Valor | Descripción |
|-----------|-------|-------------|
| α | 0.36 | Participación del capital |
| β | 0.99 | Factor de descuento |
| δ | 0.025 | Tasa de depreciación |
| σ | 2.0 | Aversión al riesgo (consumo) |
| γ | 1.0 | Peso del ocio |
| ψ | 1.0 | Curvatura del ocio |
| ρ | 0.90 | Persistencia del shock TFP |
| σ_ε | 1% | Desviación típica de la innovación |
