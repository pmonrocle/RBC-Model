"""
RBC Model — Planificador Social
================================
Utilidad: CRRA en consumo + CRRA en ocio (1-l_t)
max E_0 Σ β^t [ (c_t^{1-σ}-1)/(1-σ) + γ (1-l_t)^{1-ψ}/(1-ψ) ]
s.a. k_{t+1} = θ_t k_t^α l_t^{1-α} - c_t + (1-δ) k_t
     log θ_t = (1-ρ)θ̄ + ρ log θ_{t-1} + ε_t,  ε_t ~ N(0,σ_ε²)

Solución: log-linealización + Blanchard-Kahn (QZ decomposition).
"""

import numpy as np
import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy.linalg import ordqz

# ─────────────────────────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="RBC — Planificador Social",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    .block-container { padding-top: 1.5rem; }
    .metric-card {
        background: #1e2333;
        border: 1px solid #2d3348;
        border-radius: 8px;
        padding: 12px 16px;
        margin-bottom: 8px;
    }
    .stTabs [data-baseweb="tab"] { font-size: 14px; }
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────
# SIDEBAR — PARAMETERS
# ─────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## Parámetros del Modelo")
    st.markdown("### 🏭 Tecnología")
    alpha   = st.slider("α — participación capital",     0.20, 0.50, 0.36, 0.01)
    delta   = st.slider("δ — tasa depreciación",         0.010, 0.150, 0.025, 0.005)

    st.markdown("### 👤 Preferencias")
    beta    = st.slider("β — factor descuento",          0.900, 0.999, 0.990, 0.001, format="%.3f")
    sigma   = st.slider("σ — aversión riesgo (consumo)", 0.5, 6.0, 2.0, 0.1)
    gamma   = st.slider("γ — peso del ocio",             0.1, 5.0, 1.0, 0.1)
    psi     = st.slider("ψ — curvatura ocio",            0.5, 5.0, 1.0, 0.1)

    st.markdown("### ⚡ Shock TFP")
    rho     = st.slider("ρ — persistencia shock",        0.50, 0.99, 0.90, 0.01)
    sig_eps = st.slider("σ_ε — desv. innovación (%)",   0.5, 5.0, 1.0, 0.1) / 100
    theta_bar = st.slider("θ̄ — media log TFP",          -0.1, 0.1, 0.0, 0.01)

    st.markdown("### 🔢 Simulación")
    T_sim   = st.select_slider("Periodos T",
                               options=[5_000, 10_000, 20_000, 50_000, 100_000], value=20_000)
    seed    = st.number_input("Semilla aleatoria", value=42, min_value=0, max_value=99999)
    max_lag = st.slider("Lags en correlaciones cruzadas", 2, 8, 5, 1)

    run = st.button("▶ Simular", type="primary", use_container_width=True)

# ─────────────────────────────────────────────────────────────
# MODEL SOLUTION
# ─────────────────────────────────────────────────────────────

def compute_l_ss(alpha, beta, delta, gamma, sigma, psi):
    """
    Steady state labor share from static FOC + Euler:
    (1-α) θ̄ (k/l)^α = γ (1-l)^{-ψ} c^σ
    plus resource constraint. Solve numerically.
    """
    from scipy.optimize import brentq

    # Euler: (k/l)^{1-α} β (α/k_l + 1 - δ) = 1  →  k_l = α/(1/β-1+δ)
    k_l = (alpha / (1/beta - 1 + delta)) ** (1/(1-alpha))

    # y/l = (k/l)^α;  c/l = y/l - δ*(k/l);  w = (1-α)*(k/l)^α
    yl_over_l = k_l**alpha   # y = l * k_l^alpha
    w = (1-alpha) * k_l**alpha

    # Static FOC:  w * c^{-σ} = γ*(1-l)^{-ψ}
    # c = l*(k_l^α - δ*k_l)
    c_per_l = k_l**alpha - delta*k_l  # c = c_per_l * l

    def residual(l):
        if l <= 0 or l >= 1:
            return np.nan
        c = c_per_l * l
        lhs = w * c**(-sigma)
        rhs = gamma * (1-l)**(-psi)
        return lhs - rhs

    try:
        l_ss = brentq(residual, 1e-4, 1-1e-4, xtol=1e-10)
    except Exception:
        l_ss = 0.67  # fallback: 2/3 working

    return l_ss, k_l


def build_ABC(alpha, beta, delta, sigma, gamma, psi, rho, l_ss, k_l):
    """
    Log-linearised system around deterministic SS (θ̄=1):
      A E_t z_{t+1} = B z_t + C θ_t
    where z = (k̂, ĉ), and θ̂ = log θ follows AR(1).

    FOCs:
      [1] Production:  ŷ_t = α k̂_t + (1-α) l̂_t + θ̂_t
      [2] Labour:       ŵ_t = σ ĉ_t + ψ/(1-l_ss) * l_t_deviation
          ŵ = ŷ - l̂ + (from prod fn)
      [3] Euler:        E_t ĉ_{t+1} = ĉ_t + (1/σ)(r̂_{t+1})
          r = α ŷ/k
      [4] RC:           k̂_{t+1} = (1/β) k̂_t + (ŷ_ss/k_ss) ŷ_t - (c_ss/k_ss) ĉ_t

    We closely follow the structure in build_ABC from the user's code
    (same QZ approach), adapting eta for the correct labour supply elasticity.
    """
    # Labour supply elasticity from FOC:
    # w c^{-σ} = γ (1-l)^{-ψ}  →  log-lin:
    # ŵ = σ ĉ - ψ l̂_dev/(1-l_ss)  ... actually:
    # d/dl [γ(1-l)^{-ψ}] / [γ(1-l)^{-ψ}] = ψ/(1-l_ss) * dl
    # d/dl [w c^{-σ}] → σ dc/c - 0 (static, w exog for firm)
    # Combined: ŵ - σ ĉ = -ψ_eff * l̂  where ψ_eff = ψ * l_ss/(1-l_ss)  [Hansen normalization]
    # But here labour is in utility as (1-l)^{1-ψ}/(1-ψ) so MRS = γ(1-l)^{-ψ}/u_c
    # ψ_eff = ψ * l_ss / (1-l_ss)

    psi_eff = psi * l_ss / (1.0 - l_ss)
    eta = alpha + psi_eff          # from labour market clearing

    phi_ = (1.0 - beta*(1.0-delta)) / sigma
    s    = (1.0-alpha) / eta

    lam      = (1.0/alpha) * (1.0/beta - 1.0 + delta)
    a_theta  = lam
    a_k      = 1.0/beta
    a_l      = ((1.0-alpha)/alpha) * (1.0/beta - 1.0 + delta)
    a_c      = lam - delta

    kappa_c     = 1.0 + phi_*sigma*s
    kappa_k     = phi_*((alpha-1.0) + alpha*s)
    kappa_theta = phi_*(1.0 + s)

    b11 = a_k + (alpha*a_l) / eta
    b12 = -a_c - (sigma*a_l) / eta
    c1  = a_theta + a_l / eta

    A = np.array([[1.0,      0.0   ],
                  [kappa_k, -kappa_c]])
    B = np.array([[b11,  b12 ],
                  [0.0, -1.0 ]])
    C = np.array([[c1              ],
                  [-kappa_theta*rho]])

    aux = dict(eta=eta, phi=phi_, s=s, lam=lam,
               a_theta=a_theta, a_k=a_k, a_l=a_l, a_c=a_c,
               kappa_c=kappa_c, kappa_k=kappa_k, kappa_theta=kappa_theta,
               b11=b11, b12=b12, c1=c1, psi_eff=psi_eff)
    return A, B, C, aux


def solve_BK(alpha, beta, delta, sigma, gamma, psi, rho, l_ss, k_l):
    """Blanchard-Kahn via QZ decomposition (3×3 system)."""
    A, B, C, aux = build_ABC(alpha, beta, delta, sigma, gamma, psi, rho, l_ss, k_l)

    # Expand to 3×3 with theta as additional state
    A_r = np.zeros((3, 3)); B_r = np.zeros((3, 3))
    # Variables: z = (k~, theta~, c~)  [reordering happens below]
    A_r[0,1]=A[0,0]; A_r[0,0]=A[0,1]
    B_r[0,1]=B[0,0]; B_r[0,0]=B[0,1]; B_r[0,2]=C[0,0]
    A_r[1,1]=A[1,0]; A_r[1,0]=A[1,1]
    B_r[1,1]=B[1,0]; B_r[1,0]=B[1,1]; B_r[1,2]=C[1,0]
    A_r[2,2]=1.0;    B_r[2,2]=rho

    p = [1, 2, 0]
    A2 = A_r[np.ix_(p,p)]; B2 = B_r[np.ix_(p,p)]

    S, T, alpha_, beta_, Q, Z = ordqz(B2, A2, sort="iuc")
    eig = np.abs(alpha_ / beta_)
    n_states = 2
    n_stable = (eig < 1 - 1e-10).sum()
    if n_stable != n_states:
        raise ValueError(
            f"Blanchard-Kahn: {n_stable} raíces estables (se necesitan {n_states}). "
            "Ajusta los parámetros."
        )

    Z11 = Z[:n_states, :n_states]
    Z21 = Z[n_states:, :n_states]
    Fpol = (Z21 @ np.linalg.inv(Z11)).reshape(-1)   # [phi_k, phi_theta]

    return Fpol, aux, A, B, C


def build_state_space(alpha, beta, delta, sigma, gamma, psi, rho, l_ss, k_l):
    Fpol, aux, A, B, C = solve_BK(alpha, beta, delta, sigma, gamma, psi, rho, l_ss, k_l)
    phi_k, phi_theta = Fpol

    eta = aux["eta"]
    a_theta, a_k, a_l, a_c = aux["a_theta"], aux["a_k"], aux["a_l"], aux["a_c"]
    lam = aux["lam"]

    w_lk  = (alpha - sigma*phi_k)  / eta
    w_lth = (1.0   - sigma*phi_theta) / eta

    m11 = a_k + a_l*w_lk  - a_c*phi_k
    m12 = a_theta + a_l*w_lth - a_c*phi_theta

    M = np.array([[m11, m12],
                  [0.0, rho]])
    N = np.array([[0.0], [1.0]])

    w_c = np.array([phi_k,   phi_theta])
    w_l = np.array([w_lk,    w_lth   ])
    w_y = np.array([alpha,   1.0     ]) + (1.0-alpha)*w_l

    y_over_i = lam / delta
    c_over_i = (lam - delta) / delta
    w_i = y_over_i * w_y - c_over_i * w_c

    return dict(M=M, N=N, w_c=w_c, w_l=w_l, w_y=w_y, w_i=w_i)


# ─────────────────────────────────────────────────────────────
# SIMULATION
# ─────────────────────────────────────────────────────────────

def simulate(ss, rho, sig_eps, theta_bar, T, seed):
    M, N = ss["M"], ss["N"]
    w_c, w_l, w_y, w_i = ss["w_c"], ss["w_l"], ss["w_y"], ss["w_i"]

    rng   = np.random.default_rng(seed)
    burn  = 2000
    eps   = rng.normal(0, sig_eps, T + burn)

    state = np.zeros((2, T + burn + 1))
    for t in range(T + burn):
        state[:, t+1] = M @ state[:, t] + N[:, 0] * eps[t]

    state = state[:, burn+1:]
    lnk  = state[0]
    lnth = state[1] + theta_bar   # add mean (log θ̄)

    lnc = w_c[0]*lnk + w_c[1]*lnth
    lny = w_y[0]*lnk + w_y[1]*lnth
    lnl = w_l[0]*lnk + w_l[1]*lnth
    lni = w_i[0]*lnk + w_i[1]*lnth

    return dict(k=lnk, c=lnc, y=lny, l=lnl, i=lni, theta=lnth)


# ─────────────────────────────────────────────────────────────
# STATISTICS
# ─────────────────────────────────────────────────────────────

def cross_corr(y, x, lag):
    n = len(y)
    if lag >= 0:
        a, b = y[:n-lag], x[lag:]
    else:
        a, b = y[-lag:], x[:n+lag]
    return float(np.corrcoef(a, b)[0, 1])


def compute_stats(sim, max_lag):
    lny = sim["y"]
    T   = len(lny)

    # Cross-correlations
    lags   = list(range(-max_lag, max_lag+1))
    cc = {}
    for key in ["c", "k", "i", "l"]:
        cc[key] = [cross_corr(lny, sim[key], lag) for lag in lags]

    # Volatilities
    sy = float(np.std(lny, ddof=1))
    vols = {key: float(np.std(sim[key], ddof=1)) for key in sim}

    # Autocorrelation of y
    ac_y = [cross_corr(lny, lny, lag) for lag in range(1, max_lag+2)]

    return dict(lags=lags, cc=cc, vols=vols, sy=sy, ac_y=ac_y)


# ─────────────────────────────────────────────────────────────
# IMPULSE RESPONSE FUNCTIONS
# ─────────────────────────────────────────────────────────────

def compute_irf(ss, rho, sig_eps, H=40):
    M, N = ss["M"], ss["N"]
    w_c, w_l, w_y, w_i = ss["w_c"], ss["w_l"], ss["w_y"], ss["w_i"]

    state = np.zeros((2, H+1))
    state[:, 1] = N[:, 0] * sig_eps   # unit shock at t=1

    for t in range(1, H):
        state[:, t+1] = M @ state[:, t]

    lnk  = state[0, 1:]
    lnth = state[1, 1:]
    lnc  = w_c[0]*lnk + w_c[1]*lnth
    lny  = w_y[0]*lnk + w_y[1]*lnth
    lnl  = w_l[0]*lnk + w_l[1]*lnth
    lni  = w_i[0]*lnk + w_i[1]*lnth

    return dict(k=lnk*100, c=lnc*100, y=lny*100,
                l=lnl*100, i=lni*100, theta=lnth*100)


# ─────────────────────────────────────────────────────────────
# PLOTLY HELPERS
# ─────────────────────────────────────────────────────────────

COLORS = dict(c="#60a5fa", k="#fb923c", i="#4ade80", l="#f87171", theta="#c084fc")
LABELS = dict(c="ln(c/c_ss)", k="ln(k/k_ss)", i="ln(i/i_ss)",
              l="ln(l/l_ss)", theta="ln θ")
LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(color="#c9d1e0", family="Georgia, serif", size=12),
    margin=dict(l=50, r=20, t=40, b=50),
    legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="rgba(255,255,255,0.1)",
                borderwidth=1, orientation="h", yanchor="bottom", y=1.02, x=0),
    xaxis=dict(gridcolor="rgba(255,255,255,0.07)", zerolinecolor="rgba(255,255,255,0.15)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.07)", zerolinecolor="rgba(255,255,255,0.15)"),
)


def plot_cross_corr(stats):
    lags = stats["lags"]
    fig  = go.Figure()
    fig.add_hline(y=0, line_color="rgba(255,255,255,0.15)", line_width=1)
    fig.add_vline(x=0, line_color="rgba(255,255,255,0.15)", line_width=1, line_dash="dot")
    for key in ["c", "k", "i", "l"]:
        fig.add_trace(go.Scatter(
            x=lags, y=stats["cc"][key],
            name=LABELS[key], mode="lines+markers",
            line=dict(color=COLORS[key], width=2),
            marker=dict(size=6, color=COLORS[key]),
        ))
    fig.update_layout(**LAYOUT, title="Correlación cruzada con ln(y/y_ss)",
                      xaxis_title="Lag k  ·  corr(y_t , x_{t+k})",
                      yaxis_title="Correlación",
                      yaxis_range=[-0.3, 1.05])
    return fig


def plot_irf(irf):
    H    = len(irf["y"])
    time = list(range(H))
    fig  = make_subplots(rows=2, cols=3,
                         subplot_titles=["ln θ (TFP)", "ln(y/y_ss)", "ln(c/c_ss)",
                                         "ln(k/k_ss)", "ln(i/i_ss)", "ln(l/l_ss)"],
                         vertical_spacing=0.18, horizontal_spacing=0.10)
    pairs = [("theta",1,1),("y",1,2),("c",1,3),("k",2,1),("i",2,2),("l",2,3)]
    for key, row, col in pairs:
        fig.add_trace(go.Scatter(
            x=time, y=irf[key],
            name=LABELS.get(key, key), mode="lines",
            line=dict(color=COLORS[key], width=2),
            showlegend=False,
        ), row=row, col=col)
        fig.add_hline(y=0, line_color="rgba(255,255,255,0.1)", line_width=1,
                      row=row, col=col)
    fig.update_layout(**LAYOUT, title=f"Función de Impulso-Respuesta — shock 1 σ_ε en TFP",
                      height=480)
    for i in range(1, 7):
        fig.update_yaxes(gridcolor="rgba(255,255,255,0.07)",
                         zerolinecolor="rgba(255,255,255,0.1)", row=(i-1)//3+1, col=(i-1)%3+1)
        fig.update_xaxes(gridcolor="rgba(255,255,255,0.07)",
                         title_text="Periodos", row=(i-1)//3+1, col=(i-1)%3+1)
    return fig


def plot_simulation(sim, n_show=300):
    fig = go.Figure()
    t   = list(range(n_show))
    for key in ["y", "c", "i", "l"]:
        fig.add_trace(go.Scatter(
            x=t, y=sim[key][:n_show]*100,
            name=LABELS[key], mode="lines",
            line=dict(color=COLORS[key], width=1.5),
        ))
    fig.add_hline(y=0, line_color="rgba(255,255,255,0.15)", line_width=1)
    fig.update_layout(**LAYOUT,
                      title=f"Simulación (primeros {n_show} periodos)",
                      xaxis_title="Periodo", yaxis_title="Desviación del SS (%)")
    return fig


def plot_vol_bar(stats):
    vars_ = ["c", "k", "i", "l"]
    sy    = stats["sy"]
    ratios = [stats["vols"][v] / sy for v in vars_]
    fig   = go.Figure(go.Bar(
        x=[LABELS[v] for v in vars_], y=ratios,
        marker_color=[COLORS[v] for v in vars_],
        marker_line_color="rgba(0,0,0,0)", opacity=0.85,
    ))
    fig.add_hline(y=1, line_dash="dot",
                  line_color="rgba(255,255,255,0.4)",
                  annotation_text="σ(y)", annotation_position="right")
    fig.update_layout(**LAYOUT,
                      title="Volatilidad relativa · σ(x)/σ(y)",
                      yaxis_title="σ(x)/σ(y)",
                      xaxis_title="")
    return fig


# ─────────────────────────────────────────────────────────────
# MAIN PAGE
# ─────────────────────────────────────────────────────────────

st.markdown("# Modelo RBC — Planificador Social")

# ── Problem statement
with st.expander("📐 Problema del Planificador Social", expanded=False):
    st.latex(r"""
    \max_{\{c_t, k_{t+1}, l_t\}_{t=0}^{\infty}}
    \mathbb{E}_0 \left\{
        \sum_{t=0}^{\infty} \beta^t
        \left[
            \frac{c_t^{1-\sigma}-1}{1-\sigma}
            + \gamma \frac{(1-l_t)^{1-\psi}}{1-\psi}
        \right]
    \right\}
    """)
    st.latex(r"""
    \text{s.a.} \quad
    k_{t+1} = \theta_t k_t^{\alpha} l_t^{1-\alpha} - c_t + (1-\delta)k_t
    """)
    st.latex(r"""
    \log\theta_t = (1-\rho)\bar{\theta} + \rho\log\theta_{t-1} + \varepsilon_t,
    \qquad \varepsilon_t \overset{iid}{\sim} \mathcal{N}(0,\sigma_\varepsilon^2)
    """)
    st.markdown("""
    **Método de solución**: log-linealización alrededor del estado estacionario determinista
    (θ̄ = 1 normalizado) + descomposición QZ (Blanchard-Kahn).
    """)

# ─── Run on button press OR first load
if "results" not in st.session_state:
    run = True   # run on first load

if run:
    with st.spinner("Resolviendo el modelo y simulando…"):
        try:
            # Steady state
            l_ss, k_l = compute_l_ss(alpha, beta, delta, gamma, sigma, psi)

            # State space
            ss = build_state_space(alpha, beta, delta, sigma, gamma, psi, rho, l_ss, k_l)

            # Steady state levels
            c_per_l = k_l**alpha - delta*k_l
            kss = k_l * l_ss
            css = c_per_l * l_ss
            yss = kss**alpha * l_ss**(1-alpha)
            iss = yss - css
            wss = (1-alpha) * yss / l_ss
            rss = alpha * yss / kss

            # Simulate
            sim = simulate(ss, rho, sig_eps, theta_bar, T_sim, seed)

            # Stats
            stats = compute_stats(sim, max_lag)

            # IRF
            irf = compute_irf(ss, rho, sig_eps)

            st.session_state["results"] = dict(
                ss=ss, sim=sim, stats=stats, irf=irf,
                ss_vals=dict(kss=kss, css=css, yss=yss, iss=iss,
                             lss=l_ss, wss=wss, rss=rss),
                params=dict(alpha=alpha, beta=beta, delta=delta,
                            sigma=sigma, gamma=gamma, psi=psi,
                            rho=rho, sig_eps=sig_eps)
            )
            st.success("Modelo resuelto correctamente.", icon="✅")

        except Exception as e:
            st.error(f"❌ Error al resolver el modelo: {e}")
            st.stop()

# ─── Retrieve
res    = st.session_state["results"]
sim    = res["sim"]
stats  = res["stats"]
irf    = res["irf"]
ss_v   = res["ss_vals"]

# ─────────────────────────────────────────────────────────────
# KPIs — Steady State
# ─────────────────────────────────────────────────────────────
st.markdown("### Estado Estacionario")
cols = st.columns(6)
kpi_data = [
    ("k_ss", ss_v["kss"], "Stock de capital"),
    ("c_ss", ss_v["css"], "Consumo"),
    ("y_ss", ss_v["yss"], "Producción"),
    ("i_ss", ss_v["iss"], "Inversión"),
    ("l_ss", ss_v["lss"], "Horas trabajadas"),
    ("r_ss", ss_v["rss"], "Tipo de interés"),
]
for col, (label, val, help_txt) in zip(cols, kpi_data):
    col.metric(label=label, value=f"{val:.4f}", help=help_txt)

# ─────────────────────────────────────────────────────────────
# TABS
# ─────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4 = st.tabs([
    "📊 Correlaciones cruzadas",
    "⚡ Impulso-Respuesta",
    "📈 Simulación",
    "📋 Estadísticos",
])

# ── Tab 1: Cross-correlations
with tab1:
    st.plotly_chart(plot_cross_corr(stats), use_container_width=True)

    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Correlación contemporánea con y (lag 0)**")
        lag0_idx = stats["lags"].index(0)
        for key in ["c", "k", "i", "l"]:
            val = stats["cc"][key][lag0_idx]
            bar = "█" * int(abs(val)*20)
            st.markdown(f"`{LABELS[key]}`  {val:+.4f}  {bar}")
    with c2:
        st.markdown("**Correlación cruzada — tabla completa**")
        import pandas as pd
        df_cc = pd.DataFrame(
            {LABELS[k]: stats["cc"][k] for k in ["c","k","i","l"]},
            index=[f"lag {l:+d}" for l in stats["lags"]]
        ).round(4)
        st.dataframe(df_cc, use_container_width=True)

# ── Tab 2: IRF
with tab2:
    st.plotly_chart(plot_irf(irf), use_container_width=True)
    st.caption(
        f"Shock de 1 σ_ε = {res['params']['sig_eps']*100:.2f}% "
        "en el proceso AR(1) de TFP. Respuesta en % de desviación del estado estacionario."
    )

# ── Tab 3: Simulation
with tab3:
    n_show = st.slider("Periodos a mostrar", 50, min(T_sim, 1000), 200, 50)
    st.plotly_chart(plot_simulation(sim, n_show), use_container_width=True)
    st.plotly_chart(plot_vol_bar(stats), use_container_width=True)

# ── Tab 4: Statistics table
with tab4:
    sy = stats["sy"]

    st.markdown("#### Momentos de primer y segundo orden")
    rows = []
    for key in ["y", "c", "k", "i", "l"]:
        lbl   = LABELS.get(key, key)
        std_v = stats["vols"][key]
        mn    = float(np.mean(sim[key]))
        cc0   = stats["cc"].get(key, [None]*(len(stats["lags"])))
        lag0_idx = stats["lags"].index(0)
        corr_y = cc0[lag0_idx] if key != "y" else 1.0
        rows.append({
            "Variable": lbl,
            "Media (log-dev)": f"{mn:.5f}",
            "σ(x)": f"{std_v*100:.3f}%",
            "σ(x)/σ(y)": f"{std_v/sy:.3f}",
            "corr(y,x) lag 0": f"{corr_y:.4f}",
        })
    import pandas as pd
    st.dataframe(pd.DataFrame(rows).set_index("Variable"), use_container_width=True)

    st.markdown("#### Autocorrelación de ln(y/y_ss)")
    ac_df = pd.DataFrame({
        "Lag": [f"lag {i+1}" for i in range(len(stats["ac_y"]))],
        "Autocorrelación": [f"{v:.4f}" for v in stats["ac_y"]],
    }).set_index("Lag")
    st.dataframe(ac_df, use_container_width=True)

    st.markdown("#### Descomposición del output")
    yss_val = ss_v["yss"]; css_val = ss_v["css"]; iss_val = ss_v["iss"]
    st.markdown(
        f"  y_ss = **{yss_val:.4f}** = c_ss {css_val:.4f} "
        f"({css_val/yss_val*100:.1f}%) + i_ss {iss_val:.4f} "
        f"({iss_val/yss_val*100:.1f}%)"
    )

# ─────────────────────────────────────────────────────────────
# FOOTER
# ─────────────────────────────────────────────────────────────
st.divider()
st.caption(
    "Modelo RBC — Planificador Social · Preferencias CRRA separables en consumo y ocio · "
    "Solución por log-linealización + descomposición QZ (Blanchard-Kahn) · "
    "Código disponible en GitHub"
)
